import React from 'react';
import './index.css';

function BuyButton() {
  return <button className="buy-button">Add to Cart</button>;
}

export default BuyButton;
